BOOKMARKS
=============

INTRO
=====
This module provides a unique menu for each authorized user.


INSTALLATION
============
1) Place this module directory into your Drupal modules directory.

2) Enable the bookmarks module in Drupal, at:
   administration -> site configuration -> modules (admin/build/modules)

3) Activate the Bookmarks block at:
   administration -> site building -> blocks (admin/build/block)

