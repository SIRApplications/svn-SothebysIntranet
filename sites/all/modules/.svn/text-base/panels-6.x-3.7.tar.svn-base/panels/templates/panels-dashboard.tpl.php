<?php
// $Id: panels-dashboard.tpl.php,v 1.1.2.4 2010/07/23 21:49:03 merlinofchaos Exp $
?>
<div class="panels-dashboard">
  <div class="dashboard-left">
    <?php print $left; ?>
  </div>

  <div class="dashboard-right">
    <?php print $right; ?>
  </div>
</div>
