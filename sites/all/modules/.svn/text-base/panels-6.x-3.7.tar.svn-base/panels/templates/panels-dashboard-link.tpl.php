<?php
// $Id: panels-dashboard-link.tpl.php,v 1.1.2.1 2010/07/23 21:49:03 merlinofchaos Exp $
?>
<div class="dashboard-entry clear-block">
  <div class="dashboard-text">
    <div class="dashboard-link">
      <?php print $link['title']; ?>
    </div>
    <div class="description">
      <?php print $link['description']; ?>
    </div>
  </div>
</div>
